export { usePermissions, useHasPermission } from './usePermissions';
